public class Endereco {
    String logradouro;
    String complemento;
    String numero;
    String bairro;
    String cidade;
    String cep;
}
