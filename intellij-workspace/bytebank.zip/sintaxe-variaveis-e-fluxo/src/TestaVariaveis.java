public class TestaVariaveis {

	public static void main(String[] args) {
	
		System.out.println("ola novo teste");

		int idade = 37;

		System.out.println("a idade é " + idade + ", parabéns!");
	}
}
